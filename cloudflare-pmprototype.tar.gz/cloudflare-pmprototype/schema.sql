-- Feedback table to store all aggregated feedback
CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT NOT NULL, -- 'email', 'github', 'social', 'support_ticket', 'forum'
    source_id TEXT, -- Original ID from source system
    product TEXT NOT NULL,
    title TEXT,
    content TEXT NOT NULL,
    author TEXT,
    author_email TEXT,
    sentiment TEXT, -- 'positive', 'negative', 'neutral'
    sentiment_score REAL,
    category TEXT, -- 'bug', 'feature_request', 'ux_issue', 'performance', 'other'
    priority TEXT, -- 'low', 'medium', 'high', 'critical'
    status TEXT DEFAULT 'new', -- 'new', 'reviewing', 'planned', 'resolved', 'closed'
    ai_summary TEXT,
    created_at TEXT NOT NULL,
    processed_at TEXT,
    metadata TEXT -- JSON field for source-specific data
);

-- Index for faster queries
CREATE INDEX IF NOT EXISTS idx_feedback_source ON feedback(source);
CREATE INDEX IF NOT EXISTS idx_feedback_product ON feedback(product);
CREATE INDEX IF NOT EXISTS idx_feedback_sentiment ON feedback(sentiment);
CREATE INDEX IF NOT EXISTS idx_feedback_category ON feedback(category);
CREATE INDEX IF NOT EXISTS idx_feedback_priority ON feedback(priority);
CREATE INDEX IF NOT EXISTS idx_feedback_status ON feedback(status);
CREATE INDEX IF NOT EXISTS idx_feedback_created ON feedback(created_at);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    created_at TEXT NOT NULL
);

-- Tags table for flexible categorization
CREATE TABLE IF NOT EXISTS tags (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    feedback_id INTEGER NOT NULL,
    tag TEXT NOT NULL,
    FOREIGN KEY (feedback_id) REFERENCES feedback(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_tags_feedback ON tags(feedback_id);
CREATE INDEX IF NOT EXISTS idx_tags_tag ON tags(tag);
