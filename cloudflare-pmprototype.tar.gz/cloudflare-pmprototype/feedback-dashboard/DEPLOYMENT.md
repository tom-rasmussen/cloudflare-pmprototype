# 🚀 Quick Deployment Guide

Follow these steps to deploy your Feedback Analysis Dashboard to Cloudflare:

## Prerequisites Check

- [ ] Cloudflare account created
- [ ] Wrangler CLI installed (`npm install -g wrangler`)
- [ ] Logged in to Wrangler (`wrangler login`)

## Step-by-Step Deployment

### 1. Install Dependencies

\`\`\`bash
cd feedback-dashboard
npm install
\`\`\`

### 2. Create D1 Database

\`\`\`bash
wrangler d1 create feedback_db
\`\`\`

**Important**: Copy the `database_id` from the output and update it in `wrangler.toml`:

\`\`\`toml
[[d1_databases]]
binding = "DB"
database_name = "feedback_db"
database_id = "YOUR_DATABASE_ID_HERE"  # ← Update this
\`\`\`

### 3. Initialize Database Schema

\`\`\`bash
# Local database
wrangler d1 execute feedback_db --local --file=./schema.sql

# Production database
wrangler d1 execute feedback_db --remote --file=./schema.sql
\`\`\`

### 4. Create Vectorize Index

\`\`\`bash
wrangler vectorize create feedback-embeddings --dimensions=768 --metric=cosine
\`\`\`

### 5. Create Queues

\`\`\`bash
# Main processing queue
wrangler queues create feedback-processing-queue

# Dead letter queue for failed messages
wrangler queues create feedback-dlq
\`\`\`

### 6. Test Locally

\`\`\`bash
npm run dev
\`\`\`

Open http://localhost:8787 in your browser. You should see the API welcome message.

Test the endpoints:

\`\`\`bash
# Seed test data
curl -X POST http://localhost:8787/api/seed

# Get analytics
curl http://localhost:8787/api/analytics

# Search
curl -X POST http://localhost:8787/api/search \
  -H "Content-Type: application/json" \
  -d '{"query": "app crashes"}'
\`\`\`

### 7. Deploy to Production

\`\`\`bash
npm run deploy
\`\`\`

Your Worker will be deployed to: `https://feedback-dashboard.YOUR_SUBDOMAIN.workers.dev`

### 8. Test Production

\`\`\`bash
# Replace with your actual Worker URL
export WORKER_URL="https://feedback-dashboard.YOUR_SUBDOMAIN.workers.dev"

# Seed data
curl -X POST $WORKER_URL/api/seed

# Wait 30 seconds for queue processing, then check analytics
curl $WORKER_URL/api/analytics
\`\`\`

### 9. Open Dashboard UI

Upload the `dashboard.html` file to Cloudflare Pages or serve it from your Worker:

Option A - Cloudflare Pages:
\`\`\`bash
npx wrangler pages deploy dashboard.html --project-name=feedback-dashboard-ui
\`\`\`

Option B - Test locally:
\`\`\`bash
# Open dashboard.html in your browser
# Update the API_URL in the script to your Worker URL
\`\`\`

## Verification Checklist

After deployment, verify everything works:

- [ ] Worker is deployed and accessible
- [ ] D1 database has tables (check dashboard)
- [ ] Vectorize index created (wrangler vectorize list)
- [ ] Queues created (wrangler queues list)
- [ ] Test data seeded successfully
- [ ] Analytics endpoint returns data
- [ ] Semantic search works
- [ ] Queue consumer processing messages

## Monitoring

View real-time logs:
\`\`\`bash
wrangler tail feedback-dashboard
\`\`\`

Check queue stats:
\`\`\`bash
wrangler queues consumer list feedback-processing-queue
\`\`\`

View D1 data:
\`\`\`bash
wrangler d1 execute feedback_db --remote --command "SELECT COUNT(*) FROM feedback"
\`\`\`

## Troubleshooting

### Queue not processing
\`\`\`bash
# Verify consumer is connected
wrangler queues consumer list feedback-processing-queue

# If not, add consumer manually
wrangler queues consumer add feedback-processing-queue feedback-dashboard
\`\`\`

### No AI analysis happening
- Wait 30 seconds after seeding (queue batch timeout)
- Check logs: `wrangler tail`
- Verify Workers AI binding in wrangler.toml

### Vectorize errors
\`\`\`bash
# Check index exists
wrangler vectorize list

# Verify dimensions match (768 for bge-base-en-v1.5)
wrangler vectorize get feedback-embeddings
\`\`\`

## Next Steps

1. **Integrate Real Data Sources**
   - Add webhooks for Zendesk, Intercom, etc.
   - Connect GitHub API for issue tracking
   - Set up email forwarding rules

2. **Customize AI Prompts**
   - Adjust sentiment analysis in `analyzeFeedback()`
   - Add custom categories for your product
   - Fine-tune priority assignment logic

3. **Build Frontend**
   - Create React/Vue dashboard
   - Add charts and visualizations
   - Implement user authentication

4. **Add Notifications**
   - Email alerts for high-priority feedback
   - Slack integration for new issues
   - Daily summary reports

## Cost Estimate (Free Tier)

- Workers: 100,000 requests/day (FREE)
- D1: 5GB storage + 5M reads/day (FREE)
- Workers AI: 10,000 neurons/day (FREE)
- Vectorize: 30M queries/month (FREE)
- Queues: 1M messages/month (FREE)

This dashboard should run completely free under normal usage! 🎉

## Support

- [Cloudflare Discord](https://discord.cloudflare.com)
- [Cloudflare Community](https://community.cloudflare.com)
- [Cloudflare Docs](https://developers.cloudflare.com)
