# API Testing Examples

Replace `YOUR_WORKER_URL` with your actual Worker URL.

## Setup

\`\`\`bash
# For local testing
export API_URL="http://localhost:8787"

# For production
export API_URL="https://feedback-dashboard.YOUR_SUBDOMAIN.workers.dev"
\`\`\`

## 1. Seed Test Data

\`\`\`bash
curl -X POST $API_URL/api/seed
\`\`\`

Expected output:
\`\`\`json
{
  "success": true,
  "message": "Seeded 10 feedback items",
  "ids": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
}
\`\`\`

**Note**: Wait 30 seconds for queue processing to complete before checking analytics.

## 2. Submit New Feedback

\`\`\`bash
curl -X POST $API_URL/api/feedback \
  -H "Content-Type: application/json" \
  -d '{
    "source": "email",
    "content": "I love the new dashboard! It makes tracking issues so much easier.",
    "user_id": "user_999"
  }'
\`\`\`

Expected output:
\`\`\`json
{
  "success": true,
  "id": 11,
  "message": "Feedback submitted successfully. AI analysis in progress."
}
\`\`\`

## 3. Get All Feedback

\`\`\`bash
# Get latest 20 items
curl $API_URL/api/feedback?limit=20
\`\`\`

\`\`\`bash
# Filter by source
curl "$API_URL/api/feedback?source=support_ticket&limit=10"
\`\`\`

\`\`\`bash
# Filter by sentiment
curl "$API_URL/api/feedback?sentiment=negative&limit=15"
\`\`\`

\`\`\`bash
# Multiple filters
curl "$API_URL/api/feedback?source=github&category=bug&sentiment=negative"
\`\`\`

## 4. Semantic Search

\`\`\`bash
# Search for performance issues
curl -X POST $API_URL/api/search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "slow performance mobile app",
    "topK": 5
  }'
\`\`\`

\`\`\`bash
# Search for crashes
curl -X POST $API_URL/api/search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "application crashes freezing",
    "topK": 10
  }'
\`\`\`

\`\`\`bash
# Search for positive feedback
curl -X POST $API_URL/api/search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "love great excellent amazing",
    "topK": 5
  }'
\`\`\`

Expected output:
\`\`\`json
{
  "success": true,
  "query": "slow performance mobile app",
  "count": 2,
  "results": [
    {
      "score": 0.85,
      "feedback": {
        "id": 5,
        "source": "community_forum",
        "content": "The mobile app is much slower than the web version...",
        "sentiment": "negative",
        "category": "performance"
      },
      "metadata": {
        "source": "community_forum",
        "sentiment": "negative"
      }
    }
  ]
}
\`\`\`

## 5. Get Analytics

\`\`\`bash
curl $API_URL/api/analytics
\`\`\`

Expected output:
\`\`\`json
{
  "success": true,
  "analytics": {
    "total_feedback": 10,
    "sentiment_distribution": [
      { "sentiment": "positive", "count": 3 },
      { "sentiment": "negative", "count": 5 },
      { "sentiment": "neutral", "count": 2 }
    ],
    "category_distribution": [
      { "category": "bug", "count": 2 },
      { "category": "feature_request", "count": 1 },
      { "category": "performance", "count": 2 }
    ],
    "source_distribution": [
      { "source": "email", "count": 2 },
      { "source": "support_ticket", "count": 3 },
      { "source": "social_media", "count": 2 }
    ],
    "recent_feedback": [...]
  }
}
\`\`\`

## 6. Batch Submit Multiple Feedback

\`\`\`bash
# Submit urgent security issue
curl -X POST $API_URL/api/feedback \
  -H "Content-Type: application/json" \
  -d '{
    "source": "github",
    "content": "CRITICAL: Found SQL injection vulnerability in login endpoint. Please patch immediately!",
    "user_id": "security_researcher_001"
  }'

# Submit feature request
curl -X POST $API_URL/api/feedback \
  -H "Content-Type: application/json" \
  -d '{
    "source": "community_forum",
    "content": "Would love to see dark mode support. My eyes hurt after long sessions.",
    "user_id": "user_456"
  }'

# Submit positive feedback
curl -X POST $API_URL/api/feedback \
  -H "Content-Type: application/json" \
  -d '{
    "source": "email",
    "content": "Your customer support team is amazing! Solved my issue in 10 minutes.",
    "user_id": "user_789"
  }'
\`\`\`

## 7. Advanced Query Examples

### Get high-priority negative feedback
\`\`\`bash
# First get all negative feedback
curl "$API_URL/api/feedback?sentiment=negative" | jq '.feedback[] | select(.priority == "high")'
\`\`\`

### Count feedback by source
\`\`\`bash
curl "$API_URL/api/analytics" | jq '.analytics.source_distribution'
\`\`\`

### Find security-related feedback
\`\`\`bash
curl -X POST $API_URL/api/search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "security vulnerability authentication",
    "topK": 10
  }' | jq '.results[] | select(.feedback.category == "security")'
\`\`\`

## 8. Testing Queue Processing

\`\`\`bash
# Submit feedback
FEEDBACK_ID=$(curl -s -X POST $API_URL/api/feedback \
  -H "Content-Type: application/json" \
  -d '{
    "source": "test",
    "content": "This is a test message"
  }' | jq -r '.id')

echo "Created feedback ID: $FEEDBACK_ID"

# Wait for queue processing
echo "Waiting 30 seconds for AI analysis..."
sleep 30

# Check if analysis completed
curl "$API_URL/api/feedback" | jq ".feedback[] | select(.id == $FEEDBACK_ID)"
\`\`\`

## 9. Performance Testing

\`\`\`bash
# Submit 100 feedback items rapidly
for i in {1..100}; do
  curl -s -X POST $API_URL/api/feedback \
    -H "Content-Type: application/json" \
    -d "{
      \"source\": \"load_test\",
      \"content\": \"Load test message number $i\",
      \"user_id\": \"tester_$i\"
    }" &
done

wait
echo "Submitted 100 feedback items"

# Check total count
curl "$API_URL/api/analytics" | jq '.analytics.total_feedback'
\`\`\`

## 10. Error Handling Tests

\`\`\`bash
# Missing required fields
curl -X POST $API_URL/api/feedback \
  -H "Content-Type: application/json" \
  -d '{"source": "email"}'

# Expected: 400 Bad Request

# Invalid JSON
curl -X POST $API_URL/api/search \
  -H "Content-Type: application/json" \
  -d 'invalid json'

# Expected: 400 Bad Request

# Missing query parameter
curl -X POST $API_URL/api/search \
  -H "Content-Type: application/json" \
  -d '{}'

# Expected: 400 Bad Request
\`\`\`

## Useful jq Filters

\`\`\`bash
# Pretty print all feedback
curl "$API_URL/api/feedback" | jq '.'

# Get only negative feedback content
curl "$API_URL/api/feedback?sentiment=negative" | jq '.feedback[].content'

# Count feedback by category
curl "$API_URL/api/analytics" | jq '.analytics.category_distribution | sort_by(.count) | reverse'

# Get feedback from last hour
curl "$API_URL/api/feedback" | jq '.feedback[] | select(.created_at > (now - 3600 | strftime("%Y-%m-%dT%H:%M:%S")))'
\`\`\`

## Monitoring Commands

\`\`\`bash
# Watch for new feedback (refresh every 5 seconds)
watch -n 5 "curl -s $API_URL/api/analytics | jq '.analytics.total_feedback'"

# Stream logs
wrangler tail feedback-dashboard

# Check queue depth
wrangler queues list
\`\`\`

## Load Testing with Apache Bench

\`\`\`bash
# 1000 requests with 10 concurrent connections
ab -n 1000 -c 10 -p feedback.json -T application/json \
  "$API_URL/api/feedback"
\`\`\`

Create `feedback.json`:
\`\`\`json
{
  "source": "load_test",
  "content": "Performance testing the feedback API",
  "user_id": "loadtest"
}
\`\`\`
