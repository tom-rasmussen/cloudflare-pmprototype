-- Feedback table schema for D1 database
CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT NOT NULL,           -- email, support_ticket, social_media, github, community_forum, etc.
    content TEXT NOT NULL,           -- The actual feedback text
    user_id TEXT,                    -- User identifier (optional)
    sentiment TEXT,                  -- positive, negative, neutral (AI-generated)
    category TEXT,                   -- bug, feature_request, performance, ux, etc. (AI-generated)
    priority TEXT,                   -- high, medium, low (AI-generated)
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    metadata TEXT                    -- JSON string for additional data
);

-- Indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_feedback_source ON feedback(source);
CREATE INDEX IF NOT EXISTS idx_feedback_sentiment ON feedback(sentiment);
CREATE INDEX IF NOT EXISTS idx_feedback_category ON feedback(category);
CREATE INDEX IF NOT EXISTS idx_feedback_created_at ON feedback(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_feedback_priority ON feedback(priority);

-- Optional: Create a view for analytics
CREATE VIEW IF NOT EXISTS feedback_summary AS
SELECT 
    source,
    sentiment,
    category,
    priority,
    COUNT(*) as count,
    DATE(created_at) as date
FROM feedback
WHERE sentiment IS NOT NULL
GROUP BY source, sentiment, category, priority, DATE(created_at);
