/**
 * Feedback Analysis Dashboard - Cloudflare Worker
 * 
 * This Worker provides APIs for:
 * - Ingesting feedback from multiple sources
 * - AI-powered sentiment analysis and categorization
 * - Semantic search using Vectorize
 * - Asynchronous processing via Queues
 */

export interface Env {
	DB: D1Database;
	AI: Ai;
	VECTORIZE: VectorizeIndex;
	FEEDBACK_QUEUE: Queue;
}

interface Feedback {
	id?: number;
	source: string;
	content: string;
	user_id?: string;
	sentiment?: string;
	category?: string;
	priority?: string;
	created_at?: string;
	metadata?: string;
}

interface FeedbackMessage {
	feedback: Feedback;
	action: 'process' | 'analyze';
}

export default {
	async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
		const url = new URL(request.url);
		const path = url.pathname;

		// CORS headers for development
		const corsHeaders = {
			'Access-Control-Allow-Origin': '*',
			'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
			'Access-Control-Allow-Headers': 'Content-Type',
		};

		if (request.method === 'OPTIONS') {
			return new Response(null, { headers: corsHeaders });
		}

		try {
			// API Routes
			if (path === '/api/feedback' && request.method === 'POST') {
				return await handleFeedbackSubmission(request, env, ctx);
			}

			if (path === '/api/feedback' && request.method === 'GET') {
				return await handleGetFeedback(request, env, corsHeaders);
			}

			if (path === '/api/search' && request.method === 'POST') {
				return await handleSemanticSearch(request, env, corsHeaders);
			}

			if (path === '/api/analytics' && request.method === 'GET') {
				return await handleAnalytics(request, env, corsHeaders);
			}

			if (path === '/api/seed' && request.method === 'POST') {
				return await handleSeedData(request, env, corsHeaders);
			}

			if (path === '/') {
				return new Response(JSON.stringify({
					message: 'Feedback Analysis Dashboard API',
					endpoints: {
						'POST /api/feedback': 'Submit new feedback',
						'GET /api/feedback': 'Get all feedback with filters',
						'POST /api/search': 'Semantic search feedback',
						'GET /api/analytics': 'Get analytics summary',
						'POST /api/seed': 'Generate mock feedback data'
					}
				}), {
					headers: { 'Content-Type': 'application/json', ...corsHeaders }
				});
			}

			return new Response('Not Found', { status: 404, headers: corsHeaders });

		} catch (error) {
			console.error('Error:', error);
			return new Response(JSON.stringify({ 
				error: 'Internal Server Error',
				message: error instanceof Error ? error.message : 'Unknown error'
			}), {
				status: 500,
				headers: { 'Content-Type': 'application/json', ...corsHeaders }
			});
		}
	},

	// Queue Consumer - Process feedback asynchronously
	async queue(batch: MessageBatch<FeedbackMessage>, env: Env): Promise<void> {
		for (const message of batch.messages) {
			try {
				const { feedback, action } = message.body;

				if (action === 'process') {
					// Generate AI analysis
					const analysis = await analyzeFeedback(feedback.content, env);
					
					// Generate embeddings for semantic search
					const embeddings = await generateEmbeddings(feedback.content, env);
					
					// Update database with AI insights
					await env.DB.prepare(`
						UPDATE feedback 
						SET sentiment = ?, category = ?, priority = ?
						WHERE id = ?
					`).bind(
						analysis.sentiment,
						analysis.category,
						analysis.priority,
						feedback.id
					).run();

					// Store in Vectorize for semantic search
					if (feedback.id) {
						await env.VECTORIZE.upsert([{
							id: feedback.id.toString(),
							values: embeddings,
							metadata: {
								source: feedback.source,
								sentiment: analysis.sentiment,
								category: analysis.category,
								content: feedback.content.substring(0, 500) // Store preview
							}
						}]);
					}

					message.ack();
				}
			} catch (error) {
				console.error('Queue processing error:', error);
				message.retry();
			}
		}
	}
};

/**
 * Submit new feedback - adds to database and queues for AI processing
 */
async function handleFeedbackSubmission(
	request: Request, 
	env: Env, 
	ctx: ExecutionContext
): Promise<Response> {
	const feedback: Feedback = await request.json();

	// Validate input
	if (!feedback.content || !feedback.source) {
		return new Response(JSON.stringify({ 
			error: 'Missing required fields: content and source' 
		}), {
			status: 400,
			headers: { 'Content-Type': 'application/json' }
		});
	}

	// Insert feedback into D1
	const result = await env.DB.prepare(`
		INSERT INTO feedback (source, content, user_id, created_at, metadata)
		VALUES (?, ?, ?, datetime('now'), ?)
	`).bind(
		feedback.source,
		feedback.content,
		feedback.user_id || null,
		feedback.metadata ? JSON.stringify(feedback.metadata) : null
	).run();

	const feedbackId = result.meta.last_row_id;

	// Queue for async AI processing
	await env.FEEDBACK_QUEUE.send({
		feedback: { ...feedback, id: feedbackId },
		action: 'process'
	});

	return new Response(JSON.stringify({
		success: true,
		id: feedbackId,
		message: 'Feedback submitted successfully. AI analysis in progress.'
	}), {
		headers: { 
			'Content-Type': 'application/json',
			'Access-Control-Allow-Origin': '*'
		}
	});
}

/**
 * Get feedback with optional filters
 */
async function handleGetFeedback(
	request: Request, 
	env: Env, 
	corsHeaders: Record<string, string>
): Promise<Response> {
	const url = new URL(request.url);
	const source = url.searchParams.get('source');
	const sentiment = url.searchParams.get('sentiment');
	const category = url.searchParams.get('category');
	const limit = parseInt(url.searchParams.get('limit') || '50');

	let query = 'SELECT * FROM feedback WHERE 1=1';
	const params: any[] = [];

	if (source) {
		query += ' AND source = ?';
		params.push(source);
	}
	if (sentiment) {
		query += ' AND sentiment = ?';
		params.push(sentiment);
	}
	if (category) {
		query += ' AND category = ?';
		params.push(category);
	}

	query += ' ORDER BY created_at DESC LIMIT ?';
	params.push(limit);

	const result = await env.DB.prepare(query).bind(...params).all();

	return new Response(JSON.stringify({
		success: true,
		count: result.results.length,
		feedback: result.results
	}), {
		headers: { 'Content-Type': 'application/json', ...corsHeaders }
	});
}

/**
 * Semantic search using Vectorize
 */
async function handleSemanticSearch(
	request: Request, 
	env: Env, 
	corsHeaders: Record<string, string>
): Promise<Response> {
	const { query, topK = 10 } = await request.json();

	if (!query) {
		return new Response(JSON.stringify({ 
			error: 'Missing query parameter' 
		}), {
			status: 400,
			headers: { 'Content-Type': 'application/json', ...corsHeaders }
		});
	}

	// Generate embeddings for the search query
	const queryEmbeddings = await generateEmbeddings(query, env);

	// Search in Vectorize
	const results = await env.VECTORIZE.query(queryEmbeddings, {
		topK,
		returnMetadata: 'all'
	});

	// Fetch full feedback details from D1
	const feedbackIds = results.matches.map(match => match.id);
	
	if (feedbackIds.length === 0) {
		return new Response(JSON.stringify({
			success: true,
			count: 0,
			results: []
		}), {
			headers: { 'Content-Type': 'application/json', ...corsHeaders }
		});
	}

	const placeholders = feedbackIds.map(() => '?').join(',');
	const feedbackResult = await env.DB.prepare(`
		SELECT * FROM feedback WHERE id IN (${placeholders})
	`).bind(...feedbackIds).all();

	// Combine vector scores with full feedback data
	const enrichedResults = results.matches.map(match => {
		const feedback = feedbackResult.results.find(
			f => f.id.toString() === match.id
		);
		return {
			score: match.score,
			feedback,
			metadata: match.metadata
		};
	});

	return new Response(JSON.stringify({
		success: true,
		query,
		count: enrichedResults.length,
		results: enrichedResults
	}), {
		headers: { 'Content-Type': 'application/json', ...corsHeaders }
	});
}

/**
 * Get analytics summary
 */
async function handleAnalytics(
	request: Request, 
	env: Env, 
	corsHeaders: Record<string, string>
): Promise<Response> {
	// Total feedback count
	const totalResult = await env.DB.prepare(
		'SELECT COUNT(*) as count FROM feedback'
	).first();

	// Sentiment distribution
	const sentimentResult = await env.DB.prepare(`
		SELECT sentiment, COUNT(*) as count 
		FROM feedback 
		WHERE sentiment IS NOT NULL
		GROUP BY sentiment
	`).all();

	// Category distribution
	const categoryResult = await env.DB.prepare(`
		SELECT category, COUNT(*) as count 
		FROM feedback 
		WHERE category IS NOT NULL
		GROUP BY category
	`).all();

	// Source distribution
	const sourceResult = await env.DB.prepare(`
		SELECT source, COUNT(*) as count 
		FROM feedback 
		GROUP BY source
	`).all();

	// Recent feedback
	const recentResult = await env.DB.prepare(`
		SELECT * FROM feedback 
		ORDER BY created_at DESC 
		LIMIT 5
	`).all();

	return new Response(JSON.stringify({
		success: true,
		analytics: {
			total_feedback: totalResult?.count || 0,
			sentiment_distribution: sentimentResult.results,
			category_distribution: categoryResult.results,
			source_distribution: sourceResult.results,
			recent_feedback: recentResult.results
		}
	}), {
		headers: { 'Content-Type': 'application/json', ...corsHeaders }
	});
}

/**
 * Generate mock feedback data for testing
 */
async function handleSeedData(
	request: Request, 
	env: Env, 
	corsHeaders: Record<string, string>
): Promise<Response> {
	const mockFeedback = [
		{
			source: 'email',
			content: 'The new dashboard is confusing and hard to navigate. I spent 20 minutes trying to find the export button.',
			user_id: 'user_123'
		},
		{
			source: 'support_ticket',
			content: 'Love the new features! The AI-powered search is incredibly fast and accurate. Great job!',
			user_id: 'user_456'
		},
		{
			source: 'social_media',
			content: 'App keeps crashing when I try to upload files larger than 10MB. Very frustrating.',
			user_id: 'user_789'
		},
		{
			source: 'github',
			content: 'Would be great to have dark mode support. My eyes hurt after using the app for long sessions.',
			user_id: 'user_012'
		},
		{
			source: 'community_forum',
			content: 'The mobile app is much slower than the web version. Takes 5+ seconds to load any page.',
			user_id: 'user_345'
		},
		{
			source: 'email',
			content: 'Outstanding customer support! The team resolved my issue within an hour. Highly recommend.',
			user_id: 'user_678'
		},
		{
			source: 'support_ticket',
			content: 'The API documentation is incomplete. Missing examples for authentication endpoints.',
			user_id: 'user_901'
		},
		{
			source: 'social_media',
			content: 'Pricing is too high compared to competitors. Need more affordable plans for small teams.',
			user_id: 'user_234'
		},
		{
			source: 'github',
			content: 'Found a security vulnerability in the user authentication flow. Please check your email for details.',
			user_id: 'user_567'
		},
		{
			source: 'community_forum',
			content: 'The new collaboration features are game-changing. Real-time editing works flawlessly!',
			user_id: 'user_890'
		}
	];

	const insertedIds: number[] = [];

	for (const feedback of mockFeedback) {
		const result = await env.DB.prepare(`
			INSERT INTO feedback (source, content, user_id, created_at)
			VALUES (?, ?, ?, datetime('now'))
		`).bind(feedback.source, feedback.content, feedback.user_id).run();

		const feedbackId = result.meta.last_row_id;
		insertedIds.push(feedbackId);

		// Queue for AI processing
		await env.FEEDBACK_QUEUE.send({
			feedback: { ...feedback, id: feedbackId },
			action: 'process'
		});
	}

	return new Response(JSON.stringify({
		success: true,
		message: `Seeded ${mockFeedback.length} feedback items`,
		ids: insertedIds
	}), {
		headers: { 'Content-Type': 'application/json', ...corsHeaders }
	});
}

/**
 * Analyze feedback using Workers AI
 */
async function analyzeFeedback(content: string, env: Env): Promise<{
	sentiment: string;
	category: string;
	priority: string;
}> {
	const prompt = `Analyze this product feedback and provide:
1. Sentiment: positive, negative, or neutral
2. Category: bug, feature_request, performance, ux, pricing, security, documentation, or support
3. Priority: high, medium, or low

Feedback: "${content}"

Respond in JSON format with keys: sentiment, category, priority`;

	try {
		const response = await env.AI.run('@cf/meta/llama-3.1-8b-instruct', {
			messages: [
				{ role: 'system', content: 'You are a product feedback analyzer. Respond only with valid JSON.' },
				{ role: 'user', content: prompt }
			],
			max_tokens: 150
		});

		// Parse AI response
		const text = response.response || '';
		const jsonMatch = text.match(/\{[\s\S]*\}/);
		
		if (jsonMatch) {
			const parsed = JSON.parse(jsonMatch[0]);
			return {
				sentiment: parsed.sentiment || 'neutral',
				category: parsed.category || 'general',
				priority: parsed.priority || 'medium'
			};
		}
	} catch (error) {
		console.error('AI analysis error:', error);
	}

	// Fallback to basic sentiment analysis if AI fails
	const lowerContent = content.toLowerCase();
	let sentiment = 'neutral';
	
	if (lowerContent.includes('love') || lowerContent.includes('great') || lowerContent.includes('excellent')) {
		sentiment = 'positive';
	} else if (lowerContent.includes('bad') || lowerContent.includes('terrible') || lowerContent.includes('hate')) {
		sentiment = 'negative';
	}

	return {
		sentiment,
		category: 'general',
		priority: 'medium'
	};
}

/**
 * Generate embeddings for semantic search
 */
async function generateEmbeddings(text: string, env: Env): Promise<number[]> {
	try {
		const response = await env.AI.run('@cf/baai/bge-base-en-v1.5', {
			text: [text]
		});

		if (response.data && response.data[0]) {
			return response.data[0];
		}
	} catch (error) {
		console.error('Embedding generation error:', error);
	}

	// Return zero vector as fallback
	return new Array(768).fill(0);
}
