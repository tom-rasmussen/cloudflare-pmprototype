# Feedback Analysis Dashboard

An AI-powered feedback aggregation and analysis tool built on Cloudflare's edge platform. This dashboard collects feedback from multiple sources (support tickets, social media, GitHub, emails, community forums) and uses Workers AI to automatically analyze sentiment, categorize issues, and prioritize action items.

## 🏗️ Architecture

- **Cloudflare Workers**: Serverless compute for API endpoints
- **D1 Database**: SQLite-based serverless database for feedback storage
- **Workers AI**: LLM for sentiment analysis and categorization
- **Vectorize**: Vector database for semantic search
- **Queues**: Asynchronous processing of feedback analysis

## ✨ Features

- 📥 **Multi-Source Ingestion**: Collect feedback from various channels
- 🤖 **AI Analysis**: Automatic sentiment analysis, categorization, and priority assignment
- 🔍 **Semantic Search**: Find similar feedback using vector embeddings
- 📊 **Analytics Dashboard**: Real-time insights and trends
- ⚡ **Async Processing**: Queue-based processing for scalability
- 🌍 **Global Edge Deployment**: Low-latency access worldwide

## 🚀 Setup Instructions

### Prerequisites

- Cloudflare account (Free tier works!)
- Node.js 16.17.0 or later
- Wrangler CLI

### Step 1: Install Dependencies

\`\`\`bash
npm install
\`\`\`

### Step 2: Create D1 Database

\`\`\`bash
# Create the database
wrangler d1 create feedback_db

# Copy the output database_id and update wrangler.toml
\`\`\`

Update the `database_id` in `wrangler.toml` with the ID from the output.

### Step 3: Initialize Database Schema

\`\`\`bash
# Run schema locally
wrangler d1 execute feedback_db --local --file=./schema.sql

# Run schema on production
wrangler d1 execute feedback_db --remote --file=./schema.sql
\`\`\`

### Step 4: Create Vectorize Index

\`\`\`bash
wrangler vectorize create feedback-embeddings --dimensions=768 --metric=cosine
\`\`\`

Note: Using 768 dimensions for the `@cf/baai/bge-base-en-v1.5` embedding model.

### Step 5: Create Queues

\`\`\`bash
# Create main processing queue
wrangler queues create feedback-processing-queue

# Create dead letter queue
wrangler queues create feedback-dlq
\`\`\`

### Step 6: Deploy the Worker

\`\`\`bash
# Test locally first
npm run dev

# Deploy to production
npm run deploy
\`\`\`

## 📡 API Endpoints

### 1. Submit Feedback

**POST** `/api/feedback`

Submit new feedback for analysis.

\`\`\`json
{
  "source": "support_ticket",
  "content": "The app crashes when I try to export data",
  "user_id": "user_123",
  "metadata": { "ticket_id": "TICKET-456" }
}
\`\`\`

Response:
\`\`\`json
{
  "success": true,
  "id": 42,
  "message": "Feedback submitted successfully. AI analysis in progress."
}
\`\`\`

### 2. Get Feedback

**GET** `/api/feedback?source=email&sentiment=negative&limit=20`

Query parameters:
- `source`: Filter by source (optional)
- `sentiment`: Filter by sentiment (optional)
- `category`: Filter by category (optional)
- `limit`: Max results (default: 50)

### 3. Semantic Search

**POST** `/api/search`

Find similar feedback using natural language.

\`\`\`json
{
  "query": "problems with mobile app performance",
  "topK": 10
}
\`\`\`

### 4. Analytics

**GET** `/api/analytics`

Get dashboard summary with:
- Total feedback count
- Sentiment distribution
- Category breakdown
- Source distribution
- Recent feedback

### 5. Seed Mock Data

**POST** `/api/seed`

Generate 10 mock feedback items for testing (includes various sentiments and categories).

## 🧪 Testing

### Local Development

\`\`\`bash
# Start local dev server
npm run dev

# In another terminal, seed test data
curl -X POST http://localhost:8787/api/seed

# Test semantic search
curl -X POST http://localhost:8787/api/search \
  -H "Content-Type: application/json" \
  -d '{"query": "app crashes"}'

# Get analytics
curl http://localhost:8787/api/analytics
\`\`\`

### View Logs

\`\`\`bash
# Stream live logs
npm run tail

# Or use wrangler directly
wrangler tail feedback-dashboard
\`\`\`

## 🔧 Configuration

### AI Models Used

- **LLM**: `@cf/meta/llama-3.1-8b-instruct` for sentiment analysis and categorization
- **Embeddings**: `@cf/baai/bge-base-en-v1.5` for semantic search (768 dimensions)

### Queue Configuration

- `max_batch_size`: 10 messages per batch
- `max_batch_timeout`: 30 seconds
- `max_retries`: 3 attempts before dead letter queue

### Supported Sources

- `email` - Email feedback
- `support_ticket` - Help desk tickets
- `social_media` - Twitter, Facebook, etc.
- `github` - GitHub issues/comments
- `community_forum` - Forum posts

### Categories (AI-Generated)

- `bug` - Software defects
- `feature_request` - New feature suggestions
- `performance` - Speed/efficiency issues
- `ux` - User experience feedback
- `pricing` - Pricing concerns
- `security` - Security issues
- `documentation` - Docs feedback
- `support` - Customer support feedback

## 📊 Example Workflow

1. **Feedback Submission**
   - User submits feedback via API
   - Feedback stored in D1 database
   - Message sent to processing queue

2. **AI Processing (Async)**
   - Queue consumer receives message
   - Workers AI analyzes sentiment and category
   - Embeddings generated for semantic search
   - Results stored in D1 and Vectorize

3. **Dashboard Query**
   - Product manager searches for "mobile performance issues"
   - Semantic search finds related feedback
   - Analytics show trends over time

## 🔮 Future Enhancements

- [ ] Real-time webhook integrations (Zendesk, Intercom, etc.)
- [ ] Email notifications for high-priority feedback
- [ ] Duplicate detection using embeddings
- [ ] AI-generated summaries for similar feedback clusters
- [ ] Export reports (PDF/CSV)
- [ ] Multi-language support
- [ ] Custom categorization models

## 📝 Database Schema

\`\`\`sql
feedback (
  id INTEGER PRIMARY KEY,
  source TEXT NOT NULL,
  content TEXT NOT NULL,
  user_id TEXT,
  sentiment TEXT,
  category TEXT,
  priority TEXT,
  created_at DATETIME,
  metadata TEXT
)
\`\`\`

## 🤝 Contributing

Feel free to extend this dashboard with:
- Additional data sources
- Custom AI prompts
- New analytics views
- Frontend UI (React, Vue, etc.)

## 📄 License

MIT License - Build amazing things!

## 🆘 Troubleshooting

### Queue messages not processing
- Check queue consumer is connected: `wrangler queues consumer list feedback-processing-queue`
- View queue stats: `wrangler queues list`

### Vectorize queries failing
- Verify index exists: `wrangler vectorize list`
- Check dimensions match (768 for bge-base-en-v1.5)

### D1 queries slow
- Add indexes for frequently queried columns
- Use `EXPLAIN QUERY PLAN` to optimize

## 📚 Resources

- [Cloudflare Workers Docs](https://developers.cloudflare.com/workers/)
- [D1 Database Docs](https://developers.cloudflare.com/d1/)
- [Workers AI Docs](https://developers.cloudflare.com/workers-ai/)
- [Vectorize Docs](https://developers.cloudflare.com/vectorize/)
- [Queues Docs](https://developers.cloudflare.com/queues/)
